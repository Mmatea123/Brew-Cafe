import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Order, OrderItem } from '../models/order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private apiUrl = 'http://localhost:3000/orders';
  private currentOrderSubject = new BehaviorSubject<OrderItem[]>([]);
  currentOrder$ = this.currentOrderSubject.asObservable();

  constructor(private http: HttpClient) {}

  getOrders(): Observable<Order[]> {
    return this.http.get<Order[]>(this.apiUrl);
  }

  getOrder(id: number): Observable<Order> {
    return this.http.get<Order>(`${this.apiUrl}/${id}`);
  }

  createOrder(order: Omit<Order, 'id'>): Observable<Order> {
    return this.http.post<Order>(this.apiUrl, {
      ...order,
      date: new Date().toISOString()
    });
  }

  updateOrder(order: Order): Observable<Order> {
    return this.http.put<Order>(`${this.apiUrl}/${order.id}`, order);
  }

  deleteOrder(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  // Shopping cart functionality
  addToOrder(item: OrderItem): void {
    const currentItems = this.currentOrderSubject.value;
    const existingItem = currentItems.find(i => i.id === item.id);

    if (existingItem) {
      existingItem.quantity += 1;
      this.currentOrderSubject.next([...currentItems]);
    } else {
      this.currentOrderSubject.next([...currentItems, { ...item, quantity: 1 }]);
    }
  }

  removeFromOrder(itemId: number): void {
    const currentItems = this.currentOrderSubject.value;
    this.currentOrderSubject.next(currentItems.filter(item => item.id !== itemId));
  }

  updateItemQuantity(itemId: number, quantity: number): void {
    const currentItems = this.currentOrderSubject.value;
    const updatedItems = currentItems.map(item => 
      item.id === itemId ? { ...item, quantity } : item
    );
    this.currentOrderSubject.next(updatedItems);
  }

  clearOrder(): void {
    this.currentOrderSubject.next([]);
  }

  getOrderTotal(): Observable<number> {
    return this.currentOrder$.pipe(
      map(items => items.reduce((total, item) => total + (item.price * item.quantity), 0))
    );
  }

  // Admin dashboard statistics
  getTotalRevenue(): Observable<number> {
    return this.getOrders().pipe(
      map(orders => orders.reduce((total, order) => total + order.total, 0))
    );
  }

  getTotalOrders(): Observable<number> {
    return this.getOrders().pipe(
      map(orders => orders.length)
    );
  }
}
