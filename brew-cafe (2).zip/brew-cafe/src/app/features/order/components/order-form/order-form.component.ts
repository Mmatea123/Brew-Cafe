import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OrderService } from '../../../../core/services/order.service';
import { Order, OrderItem } from '../../../../core/models/order';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-order-form',
  templateUrl: './order-form.component.html',
  styleUrls: ['./order-form.component.scss']
})
export class OrderFormComponent implements OnInit {
  orderForm: FormGroup;
  orderItems$ = this.orderService.currentOrder$.pipe(
    tap(items => console.log('Current order items:', items))
  );

  constructor(
    private fb: FormBuilder,
    private orderService: OrderService
  ) {
    this.orderForm = this.fb.group({
      customerName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.orderForm.valid) {
      this.orderItems$.subscribe(items => {
        const order: Omit<Order, 'id'> = {
          customerName: this.orderForm.value.customerName,
          items: items,
          total: this.calculateTotal(items),
          status: 'pending',
          date: new Date().toISOString()
        };
        this.orderService.createOrder(order).subscribe(() => {
          this.orderService.clearOrder();
          this.orderForm.reset();
        });
      });
    }
  }

  private calculateTotal(items: OrderItem[]): number {
    return items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }
}
