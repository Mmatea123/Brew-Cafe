import { Component } from '@angular/core';

@Component({
  selector: 'app-redeem-rewards',
  templateUrl: './redeem-rewards.component.html',
  styleUrls: ['./redeem-rewards.component.scss']
})
export class RedeemRewardsComponent {

}
